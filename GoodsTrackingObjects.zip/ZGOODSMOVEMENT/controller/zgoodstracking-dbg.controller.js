sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/m/MessageBox",
    "sap/m/MessageToast",
    "sap/ui/model/json/JSONModel"
],
    /**
     * @param {typeof sap.ui.core.mvc.Controller} Controller
     */
    function (Controller,MessageBox,MessageToast,JSONModel) {
        "use strict";

        return Controller.extend("zgoodsmovement.controller.zgoodstracking", {
            onInit: function () {

            },

            onPress:function(evt){
                var that=this;
                var ClickedBtn= evt.getSource().getText();
                if(ClickedBtn){
                   // MessageBox.information("Navigate");
                   var ObjectSelected = ClickedBtn
                    var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
                       oRouter.navTo("ScreenTwo",{
                            Object:ObjectSelected
                        });
                }else{
                    MessageBox.warning("information");
                }
            },
            OnBackPress: function ()  {
                var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");
                    // Navigate back to FLP home 
                oCrossAppNavigator.toExternal({ 
                target: { shellHash: "#" } 
                });
               
             },

        });
    });
