jQuery.sap.require("sap.ndc.BarcodeScanner");
sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/core/routing/History",
    "sap/m/MessageBox",
    "sap/m/MessageToast",
    "sap/ui/model/json/JSONModel",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator",
    "sap/ui/core/Fragment",
    'sap/ui/model/FilterType',
    "sap/ndc/BarcodeScanner",
    "zgoodsmovement/controls/ExtScanner",
    "sap/m/Token",
],
    /**
     * @param {typeof sap.ui.core.mvc.Controller} Controller
     */
    function (Controller, History, MessageBox, MessageToast, JSONModel, Filter, FilterOperator, Fragment, FilterType,BarcodeScanner,ExtScanner,Token) {
        "use strict";
        var prefixId;
		var oScanResultText;
        return Controller.extend("zgoodsmovement.controller.ScreenTwo", {
            onInit: function () {
                var that=this;
                this.oRouter = this.getOwnerComponent().getRouter();
                this.oRouter.getRoute("ScreenTwo").attachPatternMatched(function (oEvent) {
                    this.objectId = oEvent.getParameter("arguments").Object;
                    this._onPatternMatched(this.objectId);
                }, this);
                this.oMainModel = this.getOwnerComponent().getModel();
                this.oScanner = new ExtScanner({
                    settings: true,
                    valueScanned: this.onScanned.bind(this),
                    decoderKey: 'text',
                    decoders: this.getDecoders(),
                  });
                  this.getView().setModel(this.getOwnerComponent().getModel(),"main");
                // below code is used to impl scanner by ndc lib
                // prefixId = this.createId();
				// if (prefixId){
				// 	prefixId = prefixId.split("--")[0] + "--";
				// } else {
				// 	prefixId = "";
				// }
				// oScanResultText = sap.ui.getCore().byId(prefixId + 'sampleBarcodeScannerResult');

                //**** Below Fragment code is commented. In case of future use */

                // if (!this.ValueHelpToPlant) { 
                // this.ValueHelpToPlant = sap.ui.xmlfragment("zgoodsmovement.fragment.ValueHelpToPlant", this);
                // this.ValueHelpToPlant.setModel(this.getOwnerComponent().getModel());
                // }
                // if (!this.ValueHelpToDocumentId) { 
                //     this.ValueHelpToDocumentId = sap.ui.xmlfragment("zgoodsmovement.fragment.ValueHelpToDocumentId", this);
                //     this.ValueHelpToDocumentId.setModel(this.getOwnerComponent().getModel());
                //     }
                // if (!this.ValueHelpToItem) { 
                //         this.ValueHelpToItem = sap.ui.xmlfragment("zgoodsmovement.fragment.ValueHelpToItem", this);
                //         this.ValueHelpToItem.setModel(this.getOwnerComponent().getModel());
                //         }
                
            },
            onScanBtnSuccess:function(oEvent){
				if (oEvent.getParameter("cancelled")) {
					//MessageToast.show("Scan cancelled", { duration:1000 });
				} else {
                    this.oMainModel.setProperty('/scannedValue', oEvent.getParameter("text"));

                    var comp = oEvent.getSource().getId().split("-");
                    var id = comp[comp.length - 1];
                    if(id==="EntityId"){
                        this.getView().getModel().getData().Empty.EntityID =oEvent.getParameter("text").toUpperCase();                        
                        this.getView().getModel().updateBindings(true);
                        this.getView().byId(id).setValue(oEvent.getParameter("text").toUpperCase());
                        this.OnEnterEntityId();                        
                    }
                    else if(id==="DocumentNumber"){
                        var val = oEvent.getParameter("text");
                        if(val.indexOf(":")>=0){
                            // Consolidated label e.g. GR:5000000480~2023~C000930702
                            var comp = val.split(":");
                            comp = comp[1].split("~");
                            this.getView().getModel().getData().Collections.DocumentNumber = comp[2];
                            this.getView().getModel().getData().Collections.MaterialDocumentNumber = comp[0];                            
                            this.getView().getModel().updateBindings(true);
                        }
                        else{
                            var stsrtten=val.substring(0,10),
                                endten=val.substr(val.length - 10),
                                midd = val.length== 25 ? val.substring(10,15) : val.substring(10,14);
                            this.getView().getModel().getData().Collections.DocumentNumber = stsrtten;
                            this.getView().getModel().getData().Collections.Item = midd;
                            this.getView().getModel().getData().Collections.MaterialDocumentNumber = endten;
                            this.getView().getModel().updateBindings(true);
                        }
                    }
                    else{
                        this.getView().byId(id).setValue(oEvent.getParameter("text").toUpperCase());
                    }
					// if (oEvent.getParameter("text")) {
					// 	console.log(oEvent.getParameter("text"));
					// } else {
					// 	//console.log("");
					// }
				}                
            },
            onScanned: function(oEvent) {
                var that=this;
                this.oMainModel.setProperty('/scannedValue', oEvent.getParameter('value'));
                if(this.triggeredTo=="To"){that.getView().byId("to").setValue(oEvent.getParameter('value').toUpperCase());}
                if(this.triggeredTo=="From"){that.getView().byId("from").setValue(oEvent.getParameter('value').toUpperCase());}
                if(this.triggeredTo=="Collect"){
                    var val= oEvent.getParameter('value'), 
                    stsrtten=val.substring(0,10),endten=val.substr(val.length - 10),
                    midd = val.length== 25 ? val.substring(10,15) : val.substring(10,14);
                    this.getView().getModel().getData().Collections.DocumentNumber = stsrtten;
                    this.getView().getModel().getData().Collections.Item = midd;
                    this.getView().getModel().getData().Collections.MaterialDocumentNumber = endten;
                    this.getView().getModel().updateBindings(true);
                }
                if(this.triggeredTo=="Entity"){
                    this.getView().getModel().getData().Empty.EntityID =oEvent.getParameter('value').toUpperCase();
                    this.getView().getModel().updateBindings(true);
                    that.getView().byId("EntityId").setValue(oEvent.getParameter('value').toUpperCase());
                    this.OnEnterEntityId();
                }
            },
              getDecoders: function() {
                return [
                  {
                    key: 'PDF417-UII',
                    text: 'PDF417-UII',
                    decoder: this.parserPDF417UII,
                  },
                  {
                    key: 'text',
                    text: 'TEXT',
                    decoder: this.parserText,
                  },
                ];
              },
              ScanFrom: function() {
                this.triggeredTo="From";
                this.oScanner.open();
              },
              onScan: function() {
                this.triggeredTo="To";
                this.oScanner.open();
              },
              ScanCollct:function() {
                this.triggeredTo="Collect";
                this.oScanner.open();
              },
              onScanEntity:function(){
                this.triggeredTo="Entity";
                this.oScanner.open();
              },
              parserText: function(oResult) {
                var sText = '';
                var iLength = oResult.text.length;
                for (var i = 0; i !== iLength; i++) {
                  if (oResult.text.charCodeAt(i) < 32) {
                    sText += ' ';
                  } else {
                    sText += oResult.text[i];
                  }
                }
                return sText;
              },
          
              parserPDF417UII: function(oResult) {
                // we expect that
                // first symbol of UII (S - ASCII = 83) or it just last group
                var sText = oResult.text || '';
                if (oResult.format && oResult.format === 10) {
                  sText = '';
                  var iLength = oResult.text.length;
                  var aChars = [];
                  for (var i = 0; i !== iLength; i++) {
                    aChars.push(oResult.text.charCodeAt(i));
                  }
                  var iStart = -1;
                  var iGRCounter = 0;
                  var iGroupUII = -1;
                  var sTemp = '';
                  aChars.forEach(function(code, k) {
                    switch (code) {
                      case 30:
                        if (iStart === -1) {
                          iStart = k;
                          sTemp = '';
                        } else {
                          sText = sTemp;
                          iGRCounter = -1;
                        }
                        break;
                      case 29:
                        iGRCounter += 1;
                        break;
                      default:
                        if (iGRCounter > 2 && code === 83 && iGRCounter > iGroupUII) {
                          sTemp = '';
                          iGroupUII = iGRCounter;
                        }
                        if (iGroupUII === iGRCounter) {
                          sTemp += String.fromCharCode(code);
                        }
                    }
                  });
                  if (sText) {
                    sText = sText.slice(1);
                  }
                }
                return sText;
              },


            scanBarcode: function(oEvent) {
                var that = this;
                new sap.ui.require(["sap/ndc/BarcodeScanner"], function(BarcodeScanner) {
                    BarcodeScanner.scan(
                        function (mResult) {
                            alert("We got a bar code\n" +
                                 "Result: " + mResult.text + "\n" +
                                 "Format: " + mResult.format + "\n" +
                                 "Cancelled: " + mResult.cancelled);
                        },
                        function (Error) {
                            alert("Scanning failed: " + Error);
                        },
                        function (mParams) {
                            alert("Value entered: " + mParams.newValue);
                        },
                        "Enter Product Bar Code"
                    );
                });
                // sap.ndc.BarcodeScanner.scan(
                //    function (mResult) {
                //         // alert("We got a bar code\n" +
                //         // "Result: " + mResult.text + "\n" +
                //         // "Format: " + mResult.format + "\n" +
                //         // "Cancelled: " + mResult.cancelled);
                //          if (!mResult.cancelled) {
                //              var code = mResult.text;
                //              that.byId("sampleBarcodeScannerResult").setText(code);
                //          }
                //     },
                //     function (Error) {
                //         if (Error !== undefined) {
                //             MessageBox.error(Error.message);
                //         }
                //     }
                // );
            },
            _onPatternMatched: function (objectId) {
                var that = this;
                this.SetViewModel();
                var SelectedCategory = objectId;
                if (SelectedCategory == "Acceptance") {
                    this.GetPackageType();
                    this.getView().getModel().setProperty('/isAcceptance', true);
                    this.getView().getModel().setProperty('/isMovement', false);
                    this.getView().getModel().setProperty('/isCollections', false);
                    this.getView().getModel().setProperty('/isEmpty', false);
                } else if (SelectedCategory == "Movement") {
                    this.GetPackageType();
                    this.getView().getModel().setProperty('/isAcceptance', false);
                    this.getView().getModel().setProperty('/isMovement', true);
                    this.getView().getModel().setProperty('/isCollections', false);
                    this.getView().getModel().setProperty('/isEmpty', false);
                } else if (SelectedCategory == "Empty") {
                    this.getView().getModel().setProperty('/isAcceptance', false);
                    this.getView().getModel().setProperty('/isMovement', false);
                    this.getView().getModel().setProperty('/isCollections', false);
                    this.getView().getModel().setProperty('/isEmpty', true);
                } else if (SelectedCategory == "Collections") {
                    this.getView().getModel().setProperty('/isAcceptance', false);
                    this.getView().getModel().setProperty('/isMovement', false);
                    this.getView().getModel().setProperty('/isCollections', true);
                    this.getView().getModel().setProperty('/isEmpty', false);

                } else {
                    this.getView().getModel().setProperty('/isAcceptance', false);
                    this.getView().getModel().setProperty('/isMovement', false);
                    this.getView().getModel().setProperty('/isCollections', false);
                    this.getView().getModel().setProperty('/isEmpty', false);
                }
                this.getView().getModel().updateBindings(true);
            },
            onScanForValue1: function () {
                var dinkid;
                var that = this;
                var code = "";
                if (!cordova.plugins.barcodeScanner) {
                    alert("Barcode scanning not supported");
                    return;
                }
                cordova.plugins.barcodeScanner.scan(
                    function (result) {
                        if (result.format == "QR_CODE") {
                        
                            code = result.text;
                            //dinkid = result.text.split(" ")[2];
                            // Set barcode value in input field
                            that.getView().byId("from").setValue(result.codeResult.code);
                          
                        }
                    },
                    function (error) {
                        alert("Scan failed: " + error);
                    },
    
                    {
                        preferFrontCamera: true, // iOS and Android
                        showFlipCameraButton: true, // iOS and Android
                        showTorchButton: true, // iOS and Android
                        torchOn: true, // Android, launch with the torch switched on (if available)
                        saveHistory: true, // Android, save scan history (default false)
                        prompt: "Place a barcode inside the scan area", // Android
                        resultDisplayDuration: 500, // Android, display scanned text for X ms. 0 suppresses it entirely, default 1500
                        formats: "QR_CODE,PDF_417", // default: all but PDF_417 and RSS_EXPANDED
                        orientation: "landscape", // Android only (portrait|landscape), default unset so it rotates with the device
                        disableAnimations: true, // iOS
                        disableSuccessBeep: false // iOS and Android
                    }
                );
            },
            onScanForValue: function(oEvent){
                this.FieldTriggered="From";
                if(!this._oScanDialog){
                    this._oScanDialog = new sap.m.Dialog({
                        title				: "Barcode scanner",
                        contentWidth		: "540px",
                        contentHeight		: "280px",
                        horizontalScrolling	: false,
                        verticalScrolling	: false,
                        stretchOnPhone		: true,
                        content				: [new sap.ui.core.HTML({
                            id		: this.createId("scanContainer"),
                            content	: "<div />"
                        })],
                        endButton			: new sap.m.Button({
                            text	: "Cancel",
                            press	: function(oEvent){
                                this._oScanDialog.close();
                               // this.scanBarcode();
                            }.bind(this)
                        }),
                    afterOpen			: function(){
                        this._initQuagga(this.getView().byId("scanContainer").getDomRef()).done(function(){
                            // Initialisation done, start Quagga
                            Quagga.start();
                        }).fail(function(oError){
                            // Failed to initialise, show message and close dialog...this should not happen as we have
                            // already checked for camera device ni /model/models.js and hidden the scan button if none detected
                            var text ="Failed to initialise Quagga with reason code " ;
                        //	MessageBox.error(oError.message.length ? oError.message : ("Failed to initialise Quagga with reason code " + oError.name),{
                            MessageBox.error(oError.message.length ? oError.message : (text + oError.name),{
                                onClose: function(){
                                    this._oScanDialog.close();
                                   
                                }.bind(this)
                            });
                        }.bind(this));
                    }.bind(this),
                    afterClose			: function(){
                        // Dialog closed, stop Quagga
                        Quagga.stop();
                    }
                });	
                
                this.getView().addDependent(this._oScanDialog);
            }
            
            this._oScanDialog.open();
             },
            onScanForValueTo: function(oEvent){
                this.FieldTriggered="To";
                if(!this._oScanDialog){
                    this._oScanDialog = new sap.m.Dialog({
                        title				: "Barcode scanner",
                        contentWidth		: "540px",
                        contentHeight		: "280px",
                        horizontalScrolling	: false,
                        verticalScrolling	: false,
                        stretchOnPhone		: true,
                        content				: [new sap.ui.core.HTML({
                            id		: this.createId("scanContainer"),
                            content	: "<div />"
                        })],
                        endButton			: new sap.m.Button({
                            text	: "Cancel",
                            press	: function(oEvent){
                                this._oScanDialog.close();
                               // this.scanBarcode();
                            }.bind(this)
                        }),
                    afterOpen			: function(){
                        this._initQuagga(this.getView().byId("scanContainer").getDomRef()).done(function(){
                            // Initialisation done, start Quagga
                            Quagga.start();
                        }).fail(function(oError){
                            // Failed to initialise, show message and close dialog...this should not happen as we have
                            // already checked for camera device ni /model/models.js and hidden the scan button if none detected
                            var text ="Failed to initialise Quagga with reason code " ;
                        //	MessageBox.error(oError.message.length ? oError.message : ("Failed to initialise Quagga with reason code " + oError.name),{
                            MessageBox.error(oError.message.length ? oError.message : (text + oError.name),{
                                onClose: function(){
                                    this._oScanDialog.close();
                                   
                                }.bind(this)
                            });
                        }.bind(this));
                    }.bind(this),
                    afterClose			: function(){
                        // Dialog closed, stop Quagga
                        Quagga.stop();
                    }
                });	
                
                this.getView().addDependent(this._oScanDialog);
            }
            
            this._oScanDialog.open();
             },

            _initQuagga: function(oTarget){
            var oDeferred = jQuery.Deferred();

            // Initialise Quagga plugin - see https://serratus.github.io/quaggaJS/#configobject for details
            Quagga.init({
                inputStream: {
                    type		: "LiveStream",
                    target		: oTarget,
                    constraints	: {
                        width		: {min: 640},
                        height		: {min: 480},
                        facingMode	: "environment"
                    }
                },
                locator: {
                    patchSize		: "medium",
                    halfSample		: true
                },
                numOfWorkers	: 2,
                frequency		: 10,
                decoder			: {
                    readers 		: [{
                        format			: "code_128_reader",
                        config			: {}
                    }]
                },
                locate			: true
            }, function(error) {
                if (error) {
                    oDeferred.reject(error);
                } else {
                    oDeferred.resolve();
                }
            });

            if(!this._oQuaggaEventHandlersAttached){
                // Attach event handlers...

                Quagga.onProcessed(function(result) {
                    var drawingCtx = Quagga.canvas.ctx.overlay,
                        drawingCanvas = Quagga.canvas.dom.overlay;
                    
                    if (result) {
                        // The following will attempt to draw boxes around detected barcodes
                        if (result.boxes) {
                            drawingCtx.clearRect(0, 0, parseInt(drawingCanvas.getAttribute("width")), parseInt(drawingCanvas.getAttribute("height")));
                            result.boxes.filter(function (box) {
                                return box !== result.box;
                            }).forEach(function (box) {
                                Quagga.ImageDebug.drawPath(box, {x: 0, y: 1}, drawingCtx, {color: "green", lineWidth: 2});
                            });
                        }
                        
                        if (result.box) {
                            Quagga.ImageDebug.drawPath(result.box, {x: 0, y: 1}, drawingCtx, {color: "#00F", lineWidth: 2});
                        }
                        
                        if (result.codeResult && result.codeResult.code) {
                            Quagga.ImageDebug.drawPath(result.line, {x: 'x', y: 'y'}, drawingCtx, {color: 'red', lineWidth: 3});
                        }
                    }
                }.bind(this));
                
                Quagga.onDetected(function(result) {
                    // Barcode has been detected, value will be in result.codeResult.code. If requierd, validations can be done 
                    // on result.codeResult.code to ensure the correct format/type of barcode value has been picked up
                var that = this;
                    var barCodeMsg = "got bar code";
                    var barCodeErrorMsg = "Bar code error";
                    var code = "";
                    if (result.codeResult.code.length > 0) {
                                code = result.codeResult.code;
                                // alert("Successfully captured\n"+ "Code is"+code);
                                // Set barcode value in input field
                                if(that.FieldTriggered.includes("From")){that.getView().byId("from").setValue(result.codeResult.code);}
                                if(that.FieldTriggered.includes("To")){that.getView().byId("to").setValue(result.codeResult.code);}

                            }
                    // Close dialog
                    this._oScanDialog.close();
                }.bind(this));
                
                // Set flag so that event handlers are only attached once...
                this._oQuaggaEventHandlersAttached = true;
            }

            return oDeferred.promise();
            },

            onAfterRendering: function() {
				// Reset the scan result
				var oScanButton = sap.ui.getCore().byId(prefixId + 'sampleBarcodeScannerButton');
				if (oScanButton) {
					$(oScanButton.getDomRef()).on("click", function(){
						oScanResultText.setText('');
					});
				}
			},
            onScanSuccess: function(oEvent) {
				if (oEvent.getParameter("cancelled")) {
					MessageToast.show("Scan cancelled", { duration:1000 });
				} else {
					if (oEvent.getParameter("text")) {
						oScanResultText.setText(oEvent.getParameter("text"));
					} else {
						oScanResultText.setText('');
					}
				}
			},
            onScanError: function(oEvent) {
				MessageToast.show("Scan failed: " + oEvent, { duration:1000 });
			},

			onScanLiveupdate: function(oEvent) {
				// User can implement the validation about inputting value
			},

            

            // setting view to empty model
            SetViewModel: function () {
                var model = {
                    isAcceptance: false,
                    isMovement: false,
                    isEmpty: false,
                    AcceptanceForm: {
                        Plant: "",
                        DocumentID: "",
                        Item: "00001",
                        PackageType: "",
                        PackageQty: "",
                        DeliveryDocumentNumber: "",
                        PrintAcceptancelable: false,
                        Numberoflablesprint: ""
                    },
                    MovementForm: {
                        From: "",
                        Description: "",
                        To: "",
                        Description: "",
                        PackageType: ""
                    },
                    Empty: {
                        EntityID: "",
                        Description: ""
                    },
                    Collections: {
                        EmployeeeID: "",
                        EmployeeName: "",
                        DocumentNumber: "",
                        Item: "",
                        MaterialDocumentNumber: ""
                    }

                };
                var oViewModel = new sap.ui.model.json.JSONModel(model);
                this.getView().setModel(oViewModel);
            },
            GetPackageType: function () {
                var that = this;
                this.getView().setBusy(true);
                var oModelJson = new sap.ui.model.json.JSONModel();
                var filter = new sap.ui.model.Filter({
                    path: "Key",
                    operator: sap.ui.model.FilterOperator.EQ,
                    value1: 'PACKAGE'
                });
                var oFilter = new Array();
                oFilter.push(filter);
                var oModel = this.getOwnerComponent().getModel();
                oModel.read("/SearchHelpSet?", {
                    filters: oFilter,
                    success: function (oData, response) {
                        that.getView().setBusy(false);
                        console.log("success");
                        oModelJson.setData(oData);
                        if (that.objectId == "Acceptance")
                            that.getView().byId("_IDGenSelect1").setModel(oModelJson);
                        else
                            that.getView().byId("_IDGenSelect2").setModel(oModelJson);
                        //sap.ui.getCore().setModel(oModelJson, "PackagetypeModel");
                    },
                    error: function (Error) { that.getView().setBusy(false); console.log("500 0r 404 or Error"); }
                });
            },
            OnSelectingPackageType: function (oEvent) {
                var selectedPackageTypeObj = oEvent.getParameters().selectedItem.getBindingContext().getObject();
                if (this.objectId == "Acceptance")
                    this.getView().getModel().getData().AcceptanceForm.PackageType = selectedPackageTypeObj.Key;
                else
                    this.getView().getModel().getData().MovementForm.PackageType = selectedPackageTypeObj.Key;
                this.getView().getModel().updateBindings(true);
            },
            OnEnteredTo:function(oEvent){
                var that=this;
                this.getView().getModel().getData().MovementForm.To = oEvent.getParameter('value').toUpperCase();
                this.getView().getModel().updateBindings(true);
            },
            OnEnteredFrom:function(oEvent){
                var that=this;
                this.getView().getModel().getData().MovementForm.From = oEvent.getParameter('value').toUpperCase();
                this.getView().getModel().updateBindings(true);
            },
            OnEnterEntityId: function (oEvent) {
                var that = this;
                this.getView().setBusy(true);
                var enteredInput = this.getView().getModel().getData().Empty.EntityID.toUpperCase();
                this.getView().getModel().getData().Empty.EntityID = enteredInput.toUpperCase();
                if (enteredInput !== "") {
                    var oModelJson = new sap.ui.model.json.JSONModel();
                    var oModel = this.getOwnerComponent().getModel();
                    oModel.read("/EmptySet('" + enteredInput + "')", {
                        success: function (oData, response) {
                            that.getView().setBusy(false);
                            console.log("success");
                            oModelJson.setData(oData);
                            if (oData.Message.includes("Invalid Entity ID")) {
                                var ErrText = oData.Message;
                                MessageBox.error(ErrText, {
                                    onClose: function () {
                                        that._onPatternMatched(that.objectId);
                                    }
                                });
                            } else {
                                that.getView().getModel().getData().Empty.Description = oData.Description;
                                that.getView().getModel().getData().Empty.enteredInput = enteredInput;
                                that.getView().getModel().updateBindings(true);
                            }
                        },
                        error: function (Error) {
                            that.getView().setBusy(false);
                            console.log("500 0r 404 or Error");
                            MessageBox.error(Error);
                        }
                    });
                }
                else {
                    that.getView().getModel().getData().Empty.Description = "";
                    that.getView().getModel().getData().Empty.enteredInput = enteredInput;
                    that.getView().getModel().updateBindings(true);
                    that.getView().setBusy(false);
                }
            },
            //Ftn To validate int val
            OnEnterEmployeeeIDId:function(){
                // var myInteger = (/^-?\d*(\.\d+)?$/);
                // var tfValue = this.getView().byId('EmployeeeID').getValue();
                // if( !tfValue.match(myInteger) ){ 
                //     this.getView().byId('EmployeeeID').setValue("");
                // }
            },
            OnBackPress: function () {
                // window.history.go(1);
                var that = this;
                if (!this.isViewModelFormEmpty()) {
                    var oRouter = sap.ui.core.UIComponent.getRouterFor(that);
                    oRouter.navTo("zgoodstracking");
                } else {
                    MessageBox.confirm("All unsaved changes will be lost. Are you sure?", {
                        onClose: function (oAction) {
                            if (oAction === "OK") {
                                var oRouter = sap.ui.core.UIComponent.getRouterFor(that);
                                oRouter.navTo("zgoodstracking");
                            }
                        }
                    });
                }
            },
            // function to post data to sap
            OnSubmitPress: function () {
                var that = this;
                var model = this.getView().getModel().getData();
                var isValidated = this.ValidateInputForm(model);
                if (isValidated) {
                    var ServiceUrl = "", isConfirmed = false;
                    if (that.objectId == "Acceptance") {
                        ServiceUrl = "/Acceptance1Set";
                        isConfirmed = true;
                        var Object = {
                            Werks: model.AcceptanceForm.Plant,
                            Ebeln: model.AcceptanceForm.DocumentID,
                            Poskk: model.AcceptanceForm.Item,
                            Packt: model.AcceptanceForm.PackageType,
                            Packq: model.AcceptanceForm.PackageQty,
                            Ddnsr: model.AcceptanceForm.DeliveryDocumentNumber,
                            Print:model.AcceptanceForm.PrintAcceptancelable==true?'X':"",
                            Number:model.AcceptanceForm.Numberoflablesprint,
                            Error_flag: "",
                            Plant_error:""
                        };
                    } else if (that.objectId == "Movement") {
                        ServiceUrl = "/MovementSet";
                        isConfirmed = true;
                        var Object = {
                            From: model.MovementForm.From,
                            From_desc: model.MovementForm.Description,
                            To: model.MovementForm.To,
                            To_desc: model.MovementForm.To_Description,
                            Packt: model.MovementForm.PackageType,
                            Message:""
                        };
                    }
                    else if (that.objectId == "Empty") {
                        ServiceUrl = "/EmptySet";
                        isConfirmed = false;
                        var Object = {
                            Id: model.Empty.EntityID,
                            Description: model.Empty.Description,
                            Error_flag: "",
                            Message:""
                        };

                    }
                    else if (that.objectId == "Collections") {
                        ServiceUrl = "/CollectionSet";
                        isConfirmed = true;
                        var Object = {
                            BNAME: model.Collections.EmployeeeID,
                            FIRSTNAME: model.Collections.EmployeeName,
                            Ebeln: model.Collections.DocumentNumber,
                            Poskk: model.Collections.Item,
                            Mblnr: model.Collections.MaterialDocumentNumber
                        };
                    }
                    console.log(Object);
                    that.getView().setBusy(true);
                    if (!isConfirmed) {
                        var text = "Confirm the empty?";
                        MessageBox.confirm(text, {
                            //icon: MessageBox.Icon.QUESTION,
                            //styleClass: "sapUiResponsivePadding--header sapUiResponsivePadding--content sapUiResponsivePadding--footer",
                            onClose: function (oAction) {
                                if (oAction == "OK") {
                                    isConfirmed = true;
                                    var oModel = that.getOwnerComponent().getModel();
                                    oModel.create(ServiceUrl, Object, {
                                        success: function (odata) {
                                            that.getView().setBusy(false);
                                            if (that.objectId == "Empty") {
                                                if (odata.Message.includes("Successfully")) {
                                                    var text = odata.Message;
                                                    MessageBox.success(text, {

                                                        onClose: function () {
                                                            that._onPatternMatched(that.objectId);
                                                        }
                                                    });
                                                }else{
                                                    MessageBox.error(odata.Message, {
                                                        onClose: function () {
                                                            that._onPatternMatched(that.objectId);
                                                        }
                                                    });
                                                }

                                            }
                                        },
                                        error: function (err) {
                                            //var resText = "No Record Found to submit the Acceptance details.";
                                            MessageBox.error(err.responseText, {
                                                onClose: function () {
                                                    that._onPatternMatched(that.objectId);
                                                }
                                            });
                                            that.getView().setBusy(false);
                                        }
                                    });
                                }
                                that.getView().setBusy(false);
                            }
                        });
                    } else {
                        var oModel = that.getOwnerComponent().getModel();
                        oModel.create(ServiceUrl, Object, {
                            success: function (odata) {
                                that.getView().setBusy(false);
                                if (that.objectId == "Acceptance") {
                                    if (odata.Error_flag != 'X' && odata.Plant_error != 'X') {
                                        var text = "Successfully Updated.";
                                        MessageBox.success(text, {
                                            onClose: function () {
                                                that._onPatternMatched(that.objectId);
                                            }
                                        });
                                    } else {
                                        if (odata.Error_flag == 'X')
                                            var ErrText = "Document doesn't exist";
                                        if (odata.Plant_error == 'X')
                                            var ErrText = "Please enter the correct Plant details.";
                                        MessageBox.error(ErrText, {
                                            onClose: function () {
                                                that._onPatternMatched(that.objectId);
                                            }
                                        });
                                    }
                                } else if (that.objectId == "Collections") {
                                    if (odata.Message.includes("Succesfully")) {
                                    var text = odata.Message;
                                    MessageBox.success(text, {
                                        onClose: function () {
                                            that._onPatternMatched(that.objectId);
                                        }
                                    });
                                }else{
                                        var ErrText =  odata.Message;
                                        MessageBox.error(ErrText, {
                                            onClose: function () {
                                                that._onPatternMatched(that.objectId);
                                            }
                                        });
                                }

                                }else if (that.objectId == "Movement") {
                                    if (odata.Message == 'Successfully Updated') {
                                        that.getView().getModel().getData().MovementForm.Description = odata.From_desc;
                                        that.getView().getModel().getData().MovementForm.To_Description = odata.To_desc;
                                        that.getView().getModel().updateBindings(true);
                                        var text = odata.Message;
                                        MessageBox.success(text, {
                                            onClose: function () {
                                                that._onPatternMatched(that.objectId);
                                            }
                                        });
                                    } else {
                                        var ErrText = odata.Message;
                                        MessageBox.error(ErrText, {
                                            onClose: function () {
                                                that._onPatternMatched(that.objectId);
                                            }
                                        });
                                    }
                                }
                            },
                            error: function (err) {
                                //var resText = "No Record Found to submit the Acceptance details.";
                                MessageBox.error(err.responseText, {
                                    onClose: function () {
                                        that._onPatternMatched(that.objectId);
                                    }
                                });
                                that.getView().setBusy(false);
                            }
                        });
                    }
                } else {
                    if (that.objectId == "Empty") {
                        var ValidatedText = "Fill EntityID field.";
                        MessageBox.error(ValidatedText);
                    } else {
                        var ValidatedText = "Fill all the mandatory fields.";
                        MessageBox.error(ValidatedText);
                    }
                }
            },
            ValidateInputForm(OModel) {
                var that = this;
                var oData = "", isValidated = false;
                if (that.objectId == "Acceptance") {
                    oData = OModel.AcceptanceForm;
                    if (oData.Plant == "" || oData.DocumentID == "" || oData.Item == "" || oData.PackageType == ""
                        || oData.PackageQty == "") {
                        isValidated = false
                    } else
                        isValidated = true;

                } else if (that.objectId == "Movement") {
                    oData = OModel.MovementForm;
                    if (oData.From == "" || oData.To == "") {
                        isValidated = false
                    } else
                        isValidated = true;
                } else if (that.objectId == "Empty") {
                    oData = OModel.Empty;
                    if (oData.EntityID == "") {
                        isValidated = false
                    } else
                        isValidated = true;

                } else if (that.objectId == "Collections") {
                    oData = OModel.Collections;
                    //if (oData.EmployeeeID == "" || oData.DocumentNumber == ""
                    if (oData.DocumentNumber == ""
                     || oData.EmployeeName == "" || oData.MaterialDocumentNumber == "") {
                        isValidated = false
                    } else
                        isValidated = true;

                }
                return isValidated;
            },
            isViewModelFormEmpty: function () {
                var model = this.getView().getModel().getData();
                if (model.MovementForm.From != "" || model.MovementForm.Description != "" || model.MovementForm.To != ""
                    || model.MovementForm.PackageType != "" || model.MovementForm.Description != "" || model.AcceptanceForm.Plant != ""
                    || model.AcceptanceForm.DocumentID != "" || model.AcceptanceForm.Item != "00001" || model.AcceptanceForm.PackageType != ""
                    || model.AcceptanceForm.PackageQty != "" || model.AcceptanceForm.DeliveryDocumentNumber != ""
                    || model.Empty.EntityID != "" || model.Empty.Description != "" || model.Collections.EmployeeeID != "" || model.Collections.EmployeeName != ""
                    || model.Collections.DocumentNumber != "" || model.Collections.Item != "" || model.Collections.MaterialDocumentNumber != "") {
                    return true;
                } else
                    return false;
            },
            handleSelectionChange:function(oEvent){

            },
            handleSelectionFinish:function(oEvent){

            },
            onSuggestPO:function(oEvent){
                var inp = oEvent.getSource();
                //console.log(inp.getBinding("suggestionRows"));                
                var oFilter  = new sap.ui.model.Filter("PoUnique", sap.ui.model.FilterOperator.Contains, oEvent.getParameter("suggestValue"));                                                                                                                                                                              
                inp.getBinding("suggestionRows").filter([oFilter]);  
            },
            onMultiSelect:function(oEvent){
                var obj = oEvent.getParameter("selectedRow").getBindingContext("main").getObject();
                oEvent.getSource().addToken(new Token({text: obj.PoUnique, key: obj.PoUnique}));
                //new Token({text: "Token 1", key: "0001"});
            },
            onLabelPrintCbxSelect:function(oEvent){
                var sel = oEvent.getSource().getSelected();
                var val = this.getView().byId("NLP").getValue();
                if(sel && !val ){
                    this.getView().byId("NLP").setValue("1");
                }
            }
            // handleSelectPlant: function (evt) {
            //     this.plantInput = evt.getSource();
            //     this.ValueHelpToPlant.open();
            //         },
            // onConfirmPlant: function (evt) {
            //     if (evt.getParameter("selectedItem")) {
            //     this.plantInput.setValue(evt.getParameter("selectedItem").getDescription());
            //         }
            // },
            // onPlantSearch: function (oEvent) {
            //     var sValue = oEvent.getParameter("value");
            //     var oFilter = new Filter("Key", FilterOperator.Contains, sValue);
            //     var oBinding = oEvent.getParameter("itemsBinding");
            //     oBinding.filter([oFilter]);
            // },                                         
            // handleSelectDocID: function (evt) {
            //             this.DocumentIdInput = evt.getSource();
            //             this.ValueHelpToDocumentId.open();
            //                 },
            // onConfirmDocumentId: function (evt) {
            //            if (evt.getParameter("selectedItem")) {
            //                          this.DocumentIdInput.setValue(evt.getParameter("selectedItem").getDescription());
            //                      }
            //                 },
            // onDocumentIdSearch: function (oEvent) {
            //                     var sValue = oEvent.getParameter("value");
            //                     var oFilter = new Filter("Key", FilterOperator.Contains, sValue);
            //                     var oBinding = oEvent.getParameter("itemsBinding");
            //                     oBinding.filter([oFilter]);

            //             },  
            // handleItemSelect:function (evt) {
            //     this.ItemInput = evt.getSource();
            //             this.ValueHelpToItem.open();
            // },
            // onConfirmItem:function (evt) {
            //     if (evt.getParameter("selectedItem")) {
            //                   this.ItemInput.setValue(evt.getParameter("selectedItem").getDescription());
            //               }
            //          },



        });
    });